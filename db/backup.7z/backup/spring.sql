-- MySQL dump 10.13  Distrib 5.7.13, for Linux (x86_64)
--
-- Host: localhost    Database: spring
-- ------------------------------------------------------
-- Server version	5.7.13

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `auth_member`
--

DROP TABLE IF EXISTS `auth_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_member` (
  `user_srl` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '일련번호',
  `user_id` varchar(20) NOT NULL COMMENT '유저아이디',
  `password` varchar(200) DEFAULT NULL COMMENT '패스워드',
  `user_nm` varchar(50) DEFAULT NULL COMMENT '이름',
  `email` varchar(50) DEFAULT NULL COMMENT '메일',
  `use_yn` char(1) DEFAULT 'N' COMMENT '사용여부(Y:사용,N:비사용)',
  `reg_date` datetime DEFAULT NULL COMMENT '등록일',
  PRIMARY KEY (`user_srl`),
  UNIQUE KEY `UQ_USER_ID` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='유저정보';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_member`
--

LOCK TABLES `auth_member` WRITE;
/*!40000 ALTER TABLE `auth_member` DISABLE KEYS */;
INSERT INTO `auth_member` VALUES (1,'admin','$2a$10$3pfLylekH08DS6IO7RY4s.oHHhq5V1pOpiLeq3lKXz.jbfSzqNvZC','관리','','Y','2017-08-23 18:22:43');
/*!40000 ALTER TABLE `auth_member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_member_role`
--

DROP TABLE IF EXISTS `auth_member_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_member_role` (
  `user_role_srl` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '일련번호',
  `user_id` varchar(20) DEFAULT NULL COMMENT '유저아이디',
  `role_cd` varchar(10) DEFAULT NULL COMMENT '권한코드',
  PRIMARY KEY (`user_role_srl`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='유저별 권한';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_member_role`
--

LOCK TABLES `auth_member_role` WRITE;
/*!40000 ALTER TABLE `auth_member_role` DISABLE KEYS */;
INSERT INTO `auth_member_role` VALUES (1,'admin','ADM');
/*!40000 ALTER TABLE `auth_member_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_menu`
--

DROP TABLE IF EXISTS `auth_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_menu` (
  `menu_srl` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '일련번호',
  `parent_srl` int(10) DEFAULT NULL COMMENT '참조번호',
  `menu_nm` varchar(100) DEFAULT NULL COMMENT '메뉴명',
  `menu_url` varchar(100) DEFAULT NULL COMMENT '경로',
  `menu_stp` int(4) DEFAULT NULL COMMENT '순서',
  `use_yn` char(1) DEFAULT 'Y' COMMENT '사용여부',
  PRIMARY KEY (`menu_srl`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COMMENT='메뉴관리';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_menu`
--

LOCK TABLES `auth_menu` WRITE;
/*!40000 ALTER TABLE `auth_menu` DISABLE KEYS */;
INSERT INTO `auth_menu` VALUES (1,0,'사이트관리','',1,'Y'),(2,1,'권한관리','/adm/role/list',1,'Y'),(3,1,'사용자관리','/adm/user/list',2,'Y'),(4,1,'메뉴관리','',3,'Y'),(5,4,'메뉴등록','/adm/menu/list',1,'Y'),(6,4,'메뉴설정','/adm/menu/role/list',2,'Y'),(7,0,'게시판관리','',2,'Y');
/*!40000 ALTER TABLE `auth_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_menu_role`
--

DROP TABLE IF EXISTS `auth_menu_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_menu_role` (
  `role_cd` varchar(10) DEFAULT NULL COMMENT '권한코드',
  `menu_srl` int(11) DEFAULT NULL COMMENT '참조번호'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='권한별메뉴';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_menu_role`
--

LOCK TABLES `auth_menu_role` WRITE;
/*!40000 ALTER TABLE `auth_menu_role` DISABLE KEYS */;
INSERT INTO `auth_menu_role` VALUES ('ADM',1),('ADM',2),('ADM',3),('ADM',4),('ADM',5),('ADM',6),('ADM',7);
/*!40000 ALTER TABLE `auth_menu_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_role`
--

DROP TABLE IF EXISTS `auth_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_role` (
  `role_srl` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '일련번호',
  `role_cd` varchar(10) DEFAULT NULL COMMENT '권한코드',
  `role_nm` varchar(50) DEFAULT NULL COMMENT '권한',
  `use_yn` char(1) CHARACTER SET latin1 DEFAULT 'Y',
  PRIMARY KEY (`role_srl`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='권한코드';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_role`
--

LOCK TABLES `auth_role` WRITE;
/*!40000 ALTER TABLE `auth_role` DISABLE KEYS */;
INSERT INTO `auth_role` VALUES (1,'ADM','관리자','Y'),(2,'USR','사용자','Y');
/*!40000 ALTER TABLE `auth_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `com_board`
--

DROP TABLE IF EXISTS `com_board`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `com_board` (
  `board_srl` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '일련번호',
  `fid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '그룹아이디',
  `lev` int(4) unsigned NOT NULL DEFAULT '0' COMMENT '깊이',
  `stp` int(4) unsigned NOT NULL DEFAULT '0' COMMENT '순서',
  `user_id` varchar(30) NOT NULL COMMENT '아이디',
  `title` varchar(200) DEFAULT NULL COMMENT '제목',
  `content` text COMMENT '내용',
  `ip` varchar(15) DEFAULT NULL COMMENT '아이피',
  `read_cnt` int(10) unsigned DEFAULT '0' COMMENT '조회수',
  `flag` varchar(10) NOT NULL COMMENT '구분',
  `reg_date` datetime DEFAULT NULL COMMENT '등록일',
  PRIMARY KEY (`board_srl`),
  KEY `IDX_BOARD_FLAG` (`flag`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='게시판';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `com_board`
--

LOCK TABLES `com_board` WRITE;
/*!40000 ALTER TABLE `com_board` DISABLE KEYS */;
/*!40000 ALTER TABLE `com_board` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `com_board_file`
--

DROP TABLE IF EXISTS `com_board_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `com_board_file` (
  `board_file_srl` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `board_srl` int(10) unsigned DEFAULT '0',
  `file_path` varchar(100) DEFAULT NULL,
  `file_sys_nm` varchar(50) DEFAULT NULL,
  `file_real_nm` varchar(100) DEFAULT NULL,
  `file_size` varchar(10) DEFAULT NULL,
  `reg_date` datetime DEFAULT NULL,
  PRIMARY KEY (`board_file_srl`),
  KEY `IDX_BOARD_FILE` (`board_srl`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='파일목록';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `com_board_file`
--

LOCK TABLES `com_board_file` WRITE;
/*!40000 ALTER TABLE `com_board_file` DISABLE KEYS */;
/*!40000 ALTER TABLE `com_board_file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `com_board_reply`
--

DROP TABLE IF EXISTS `com_board_reply`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `com_board_reply` (
  `board_reply_srl` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '일련번호',
  `board_srl` int(10) unsigned DEFAULT '0' COMMENT '참조번호',
  `user_id` varchar(20) DEFAULT NULL COMMENT '유저아이디',
  `content` text COMMENT '내용',
  `ip` varchar(20) DEFAULT NULL COMMENT '아이피',
  `reg_date` datetime DEFAULT NULL COMMENT '등록일',
  PRIMARY KEY (`board_reply_srl`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `com_board_reply`
--

LOCK TABLES `com_board_reply` WRITE;
/*!40000 ALTER TABLE `com_board_reply` DISABLE KEYS */;
/*!40000 ALTER TABLE `com_board_reply` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-06-13 15:27:29
