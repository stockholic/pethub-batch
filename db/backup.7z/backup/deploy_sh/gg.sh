#!/usr/bin/expect -f

#10min timeOut
set timeout 600

# declare function  deploy
proc deploy { user host port password } {
    spawn ssh $user@$host -p $port
    expect -re "yes/no" {
        send "yes\r"
        exp_continue
    } -re "password:" {
        send "$password\r"
    }
    expect "$ "
    send "scp $user@$host:/usr/local/deploy_sh/gg.sh -P $port /usr/local/deploy_sh/tmp/gg4.sh\r"
    #send "/usr/local/tomcat/bin/startup.sh\r"

    expect "$ "
    send "ls -al /usr/local/deploy_sh/tmp\r"

    expect "$ "
    send "exit\r"
}

deploy merong 127.0.0.1 22 qkrtjqkddhkTsi

