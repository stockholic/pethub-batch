#!/usr/bin/expect -f
spawn ssh merong@127.0.0.1
expect "password: "
send "qkrtjqkddhkTsi\r"
expect "$ "

#send "/usr/local/tomcat/bin/shutdown.sh\r"
#expect "$ "

#sleep 2

send "/usr/local/tomcat/bin/startup.sh\r"
expect "$ "

send "exit\r"

