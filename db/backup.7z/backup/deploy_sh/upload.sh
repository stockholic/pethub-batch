#!/usr/bin/expect -f

#10min timeOut
set timeout 600


# Remote PC -> Local PC  
# $ scp [option] [account]@[remote IP]:[file path] [target path]  

# Local PC -> Remote PC  
# $ scp [option] [origin path] [account]@[remote IP]:[file path]  


# upload
proc upload { host port user password from target } {
    # ex  scp -P 22 /usr/local/deploy_sh/gg.sh merong@127.0.0.1:/usr/local/deploy_sh/tmp/gg5.sh
    spawn scp -P $port $from $user@$host:$target
    expect {
        -re "Connection timed out" { exit 1 }
        -re "try again" { exit 1 }
        -re "yes/no" { send "yes\r"; exp_continue }
        -re "password:" { send "$password\r"; exp_continue }
    }
}

# deploy
proc deploy { host port user password } {
    spawn ssh $user@$host -p $port
    expect -re "yes/no" {
        send "yes\r"
        exp_continue
    } -re "password:" {
        send "$password\r"
    }
    #expect "$ "
    #send "/usr/local/tomcat/bin/startup.sh\r"

    expect "$ "
    send "ls -al /usr/local/deploy_sh/tmp\r"

    expect "$ "
    send "exit\r"
}


upload 127.0.0.1 22 merong qkrtjqkddhkTsi /usr/local/deploy_sh/gg.sh /usr/local/deploy_sh/tmp/gg5.sh
deploy 127.0.0.1 22 merong qkrtjqkddhkTsi

