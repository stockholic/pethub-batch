#!/bin/bash

target=/usr/local/www/stockHolic

if [ -d $target ];then
	rm -rf $target
fi

unzip -q /home/merong/.jenkins/workspace/StockHolic/target/StockHolic.war -d $target


chmod -R 755 $target

BUILD_ID=dontKillMe /usr/local/tomcat/bin/startup.sh

sleep 10 

#/usr/local/tomcat/bin/startup.sh

